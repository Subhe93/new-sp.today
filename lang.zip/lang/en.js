export default {
  welcome: "Welcome",
  Home: "Home",
  Currency: "Currency",
  Gold: "Gold",
  "Currency exchange rates against the": "Currency exchange rates against the",
  "in the previous days": "in the previous days",
  "Currency Converter": "Currency Converter",
  "Gold Price": "Gold Price",
  Currency: "Currency",
  "Sell Price": "Sell Price",
  "Buy Price": "Buy Price",
  "Exchage Rate": "Exchage Rate",
  Saturday: "Saturday",
  Sunday: "Sunday",
  Monday: "Monday",
  Tuesday: "Tuesday",
  Wednesday: "Wednesday",
  Thursday: "Thursday",
  Friday: "Friday",
  "Terms of Use": "Terms of Use",
  "Privacy Policy": "Privacy Policy",
  "Contact us": "Contact us",
  Links: "Links",
  "Follow Us": "Follow Us",
  "All Rights Reserved by": "All Rights Reserved by",
  "Download our app at the following Link":
    "Download our app at the following Link",
  Lirtna: "Lirtna",
  "Previous Day": "Previous Day",
  "Next Day": "Next Day",
  meta: {
    exchange_title: "Exchange Rates and Gold in Syria Live | Lirtna",
    exchange_description:
      "Follow the latest exchange rates of the Dollar, Euro, Turkish Lira, and gold against the Syrian Pound today on Lirtna. Live updates, city-specific prices, and a currency converter.",
    exchange_and_gold_in_syria: "Exchange Rates and Gold in Syria",
    gold_title: "Gold Prices in Syria Today in Syrian Pound | Lirtna",
    gold_description:
      "Track the price of gold per gram for 21, 18, 24 karat and the ounce price in Syrian Pound (SYP) today in Syria. Regular updates on Lirtna.",
    gold_prices_in_syria: "Gold Prices in Syria Today in Syrian Pound",
    gold_subtitle:
      "Welcome to the gold section of Lirtna, your comprehensive guide to the latest gold prices in Syria, denominated in the Syrian Pound (SYP). Gold is considered a safe haven and a store of value for many, and tracking its price is essential for investors and individuals alike. Here, we provide you with updated prices for various forms of gold traded in the Syrian market, including the price per gram for the most common karats, as well as the international gold ounce price and the gold pound price.",
    gold_table_title: "Today's Gold Prices Table in Syria",
    gold_table_note:
      "Prices are updated for today. Click on the gold type for more details and historical charts.",
    gold_types_title: "Most Traded Types of Gold in Syria",
    gold_type_21:
      "21 Karat Gold Gram The most popular standard for gold jewelry and sales in Syria due to its relative hardness and suitable price. (Link to: Check today's 21k price).",
    gold_type_18:
      "18 Karat Gold Gram Also used in jewelry, especially for pieces with intricate designs, and is priced lower than 21k as it contains less pure gold. (Link to: Discover today's 18k price).",
    gold_type_ounce:
      "Gold Ounce The international standard unit for trading gold (approx. 31.1 grams), and its global price in USD is the main driver of local prices. (Link to: Track the gold ounce price today).",
    gold_type_pound:
      "Gold Pound Whether it's the Rashadi or English gold pound, these are gold coins of a known weight and karat, used for savings and investment. (Link to: See today's gold pound price).",
    gold_factors_title: "Factors Affecting Gold Price in Syria",
    gold_factor_ounce:
      "Global Ounce Price: This is the primary driver. Any rise or fall in the ounce price in USD is directly reflected in local prices.",
    gold_factor_usd:
      "USD Exchange Rate: Since gold is priced globally in USD, the USD to SYP exchange rate plays a crucial role in determining the final price in Syrian pounds.",
    gold_factor_supply:
      "Local Supply and Demand: The volume of demand for gold versus the quantities available for sale also affects the price.",
    gold_factor_craft:
      "Craftsmanship Costs (Al-Masnaiyah): This is an additional cost added by jewelers to the price of raw gold when selling gold jewelry.",
    gold_footer:
      "This page from Lirtna provides you with the latest data on gold prices traded today in the Syrian market. We hope the information and tools available, from updated buy and sell prices to historical charts, have helped you gain a clear and comprehensive understanding of this precious metal's status. The Lirtna team is committed to providing the most accurate and timely data to serve your financial needs. For more exchange rates or market analysis, we invite you to explore the other sections of our site. Lirtna - Your financial guide in Syria.",
    gold_col_type: "Type",
    gold_col_price_syp: "Gold Price (SYP)",
    gold_col_change: "Change",
    gold_col_price_usd: "Gold Price (USD)",
    gold_col_ounce_equiv: "Ounce Equivalent",
    gold_col_last_update: "Last Update",
    gold_col_buy_price: "Buy Price",
    gold_col_sell_price: "Sell Price",
    sitemap_title: "Sitemap - Browse all days and months of Lirtna",
    sitemap_subtitle:
      "Browse all available days and months for currency and gold prices on Lirtna.",
    sitemap_description:
      "Browse all available days and months for currency and gold prices on Lirtna.",
  },
  currency: {
    metaTitle: {
      city: "{currency} Price in {city} Today - SYP Exchange Rate | Lirtna",
      general: "{currency} to Syrian Pound Rate Today in Syria | Lirtna",
    },
    metaDescription: {
      city: "Track the latest {currency} to Syrian Pound exchange rate in {city} today. Live updates, buy/sell prices, currency converter, and charts on Lirtna.",
      general:
        "Track the latest {currency} to Syrian Pound exchange rate in the Syrian market today. Live updates, buy/sell prices, currency converter, and charts on Lirtna.",
    },
    heading: {
      city: "{currency} Price in {city} Today - SYP Exchange Rate",
      general: "{currency} to Syrian Pound Rate Today in Syria",
    },
    paragraph: {
      city: "This page from Lirtna provides you with the latest data on the {currency} to Syrian Pound exchange rate traded today in {city}. We hope the information and tools available, from updated buy and sell prices to the currency converter and historical charts, have helped you gain a clear and comprehensive understanding of this important currency's status. The Lirtna team is committed to providing the most accurate and timely data to serve your financial needs. For more exchange rates, market analysis, or gold prices, we invite you to explore the other sections of our site. Lirtna - Your financial guide in Syria.",
      general:
        "This page from Lirtna brings you updated data on the {currency} to Syrian Pound exchange rate in the Syrian market today. With real-time rates, currency converters, and insightful charts, we aim to support your financial decisions. Lirtna's team is dedicated to delivering fast and precise updates. Explore more sections for additional currency rates, gold prices, and in-depth market analysis. Lirtna - Your trusted economic source in Syria.",
    },
  },
  currency_table: {
    title: "{currency} to Syrian Pound",
    syp_only: "Syrian Pound",
  },
  currencies_label: "Currencies",
  currencies: {
    meta: {
      title: "Currency Exchange Rates vs Syrian Pound Today | Lirtna",
      description:
        "Comprehensive list of foreign and Arab currency exchange rates against the Syrian Pound (SYP) today. Dollar, Euro, Turkish, Riyal, Dirham and more on Lirtna.",
    },
    pageTitle: "Currency Center",
    section_main_currencies: {
      title: "Top Currencies Traded in Syria",
      description:
        "The Syrian market is significantly influenced by certain major currencies more than others. Here's a quick look at the most important ones:",
      currencies: {
        usd: "US Dollar (USD): The most important reference currency in the market, with its fluctuations directly affecting all aspects of the economy. Check today's USD rate.",
        try: "Turkish Lira (TRY): Especially important in northern regions and transit trade, its value is greatly influenced by Turkey's economic conditions. Track the TRY rate.",
        eur: "Euro (EUR): Eurozone currency, important for remittances from Europe and trade with EU countries. View the current EUR rate.",
        sar_aed:
          "Saudi Riyal (SAR) and UAE Dirham (AED): Key currencies for remittances from expats in Gulf countries. SAR rate | AED rate.",
      },
    },
    section_understanding_exchange: {
      title: "Understanding Exchange Rates in Syria",
      content:
        "You may notice differences in rates between sources or even between cities. This is due to several factors, including supply and demand, black market vs official rates (if a clear distinction exists), transfer costs, and both local and global economic conditions. At Lirtna, we strive to provide the most commonly traded rate in the parallel market and offer city-specific rates when possible. For more insight, check out our guide on the Syrian exchange market. Use Lirtna as your daily reference for currency exchange rates in Syria.",
    },
  },
  footer: {
    mainLinks: "Main Links",
    currencyPrices: "Currency Rates Today",
    currencyPricesSyria: "Currency Rates in Syria",
    goldPrices: "Gold Prices Today",
    goldPricesSyria: "Gold Prices in Syria",
    usdPrice: "US Dollar Rate",
    usdSyp: "US Dollar vs Syrian Pound",
    tryPrice: "Turkish Lira Rate",
    trySyp: "Turkish Lira vs Syrian Pound",
    euroPrice: "Euro Rate",
    euroSyp: "Euro vs Syrian Pound",

    infoResources: "Information & Resources",
    economicNews: "Economic News",
    syrianGuide: "Syrian Exchange Market Guide",

    about: "About the Site",
    aboutUs: "About Us",
    contact: "Contact Us",
    privacy: "Privacy Policy",
    terms: "Terms of Service",
    sitemap: "Sitemap",
  },
  image_download: "Download",
  euro: "Euro",
  "us-dollar": "Us dollar",
  "turkish-lira": "Turkish lira",
  menu: {
    cities: "Cities",
    usd_damascus: "USD in Damascus",
    usd_aleppo: "USD in Aleppo",
    usd_idlib: "USD in Idlib",
    try_aleppo: "TRY in Aleppo",
    try_idlib: "TRY in Idlib",
  },
  exchange_title_export: "Exchange rates of currencies and gold in Syria",
  contact: "Contact Us",
  name: "Full Name",
  email: "Email",
  phone: "Phone",
  message: "Leave us a message",
  send: "Send Message",
  text: "Feel free to contact us through the attached form or via our official social media accounts. Your voice matters to us, and your suggestion could be the reason we improve a service that benefits thousands of users every day.",
  header: "Get in touch today",
  text2: "Our social media :",
  notRobot: "I’m not a robot",
  about: "About Us",
  aboutText: "Discover today's rates and unlock smart insights",
  aboutText2:
    "Lirtna is a digital platform providing accurate and up-to-date gold and currency exchange rates tailored to the Middle East market. Our mission is to simplify financial insights and empower users, businesses, and investors with the tools they need to stay informed and ahead.",
  showDetails: "Show details",
  exchangeRate: "Exchange Rate",
  goldExchange: "Gold Exchange",
  privacyTerms: {
    title1: " Privacy Policy ",
    title2: " Terms of Use",
    privacyTitle: "Privacy Policy",
    privacyText1:
      "Your privacy matters deeply to us. We are fully committed to safeguarding your personal data and maintaining transparency about how your information is collected, used, and protected. The data we gather — such as your name, email address, and interaction history — is used solely to enhance your experience and improve our services. We never sell or share your personal information with third parties without your explicit consent, except when legally required. Our systems are secured with industry-standard protocols to prevent unauthorized access or data breaches. By using our services, you acknowledge and agree to the practices described in this policy.",
    privacyText2:
      "We respect your privacy and handle your data with care. Any information you share is kept confidential and used only to improve your experience.By using our services, you acknowledge and agree to the practices described in this policy.",
    FreePrivacyPolicy:
      "We collect only essential information to improve your experience. This includes basic data like name, email, and usage behavior. All data is stored securely and never shared with third parties without consent.",
  },

  privacyCards: {
    title1: "Privacy Policy",
    description1:
      "We collect only essential information to improve your experience. This includes basic data like name, email, and usage behavior. All data is stored securely and never shared with third parties without consent.",

    title2: "Terms & Conditions",
    description2:
      "By accessing our platform, you agree not to misuse any services, violate any laws, or attempt unauthorized access to our systems. We reserve the right to update our terms without prior notice.",

    title3: "Cookies Policy",
    description3:
      "We use cookies to enhance user experience and analyze behavior. These cookies help us improve our services. They never collect sensitive data and can be disabled anytime through browser settings.",
  },
  terms: {
    title: "Terms of Use",
    description:
      "By accessing and using our platform, you agree to comply with all applicable laws and to engage in respectful, secure, and lawful behavior. Users are expected to refrain from engaging in any activity that could harm the platform, other users, or the services we provide. This includes, but is not limited to, unauthorized access attempts, distribution of harmful software, harassment, exploitation, or use of our services for illegal or unethical purposes. We reserve the right to suspend or terminate access to users who violate these terms in order to protect the safety and integrity of our platform.",
  },
  privacy: {
    title: "Privacy Policy",
    lastUpdated: "Last updated: july 9, 2025",

    introTitle: "Introduction",
    introBody:
      "This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You. We use Your Personal data to provide and improve the Service. By using the Service, You agree to the collection and use of information in accordance with this Privacy Policy.",

    definitionsTitle: "Interpretation and Definitions",
    definitionsBody:
      "The words with capitalized initial letters have meanings defined under the following conditions. The definitions shall have the same meaning regardless of whether they appear in singular or in plural.",

    accountDefinition:
      "Account means a unique account created for You to access our Service or parts of our Service.",
    affiliateDefinition:
      "Affiliate means an entity that controls, is controlled by or is under common control with a party, where 'control' means ownership of 50% or more of the shares or voting securities.",
    companyDefinition:
      "Company refers to Lirtna, referred to as either 'the Company', 'We', 'Us' or 'Our' in this Agreement.",
    cookiesDefinition:
      "Cookies are small files placed on Your device containing browsing history details.",
    countryDefinition: "Country refers to: Sweden",
    deviceDefinition:
      "Device means any device that can access the Service such as a computer, a cellphone or a tablet.",
    personalDataDefinition:
      "Personal Data is any information that relates to an identified or identifiable individual.",
    serviceDefinition: "Service refers to the Website of Lirtna.",
    providerDefinition:
      "Service Provider means any person who processes the data on behalf of the Company.",
    usageDefinition:
      "Usage Data refers to data collected automatically by using the Service.",
    websiteDefinition:
      "Website refers to Lirtna, accessible from https://lirtna.com/",
    youDefinition:
      "You means the individual or entity accessing or using the Service.\n",

    collectTitle: "Collecting and Using Your Personal Data",
    personalDataTitle: "Types of Data Collected",
    personalDataBody:
      "We may ask You to provide Us with certain personally identifiable information including Usage Data.",
    usageDataTitle: "Usage Data",
    usageDataBody:
      "Usage Data may include information such as Your Device's IP address, browser type, browser version, pages visited, and diagnostic data.",

    trackingTitle: "Tracking Technologies and Cookies",
    trackingBody:
      "We use Cookies and similar tracking technologies to track activity on Our Service.",

    cookiesTypesTitle: "Types of Cookies",
    essentialCookies:
      "These Cookies are essential to provide You with services through the Website.",
    acceptanceCookies:
      "These Cookies identify if users have accepted the use of cookies.",
    functionalityCookies:
      "These Cookies remember choices You make, like login or language.",

    dataUsageTitle: "Use of Your Personal Data",
    dataUsageBody:
      "The Company may use Personal Data to provide and maintain our Service, manage Your Account, contact You, and for business transfers.",

    sharingDataTitle: "Sharing Your Personal Data",
    sharingDataBody:
      "We may share information with service providers, affiliates, business partners, or in legal circumstances.",

    retentionTitle: "Retention of Data",
    retentionBody:
      "We retain Your Personal Data only as long as necessary for the purposes outlined in this Privacy Policy.",

    transferTitle: "Transfer of Data",
    transferBody:
      "Your information may be transferred to computers located outside Your jurisdiction. We ensure it is treated securely.",

    deleteDataTitle: "Delete Your Data",
    deleteDataBody:
      "You have the right to delete or request deletion of Your Personal Data. Contact us to exercise this right.",

    disclosureTitle: "Disclosure of Your Personal Data",
    businessTransfer:
      "In a merger, acquisition or sale, Your Personal Data may be transferred.",
    legalDisclosure:
      "We may disclose Your Data if required by law or public authority.",
    otherLegal:
      "We may disclose Your Data to protect rights, prevent misuse, or comply with legal obligations.",

    securityTitle: "Security of Your Data",
    securityBody:
      "We strive to use commercially acceptable means to protect Your data, but no method is 100% secure.",

    childrenTitle: "Children's Privacy",
    childrenBody:
      "We do not knowingly collect personal information from anyone under 13. If we learn we have, we delete it.",

    externalLinksTitle: "Links to Other Websites",
    externalLinksBody:
      "We are not responsible for privacy practices of other websites linked from our Service.",

    changesTitle: "Changes to This Policy",
    changesBody:
      "We may update this Privacy Policy. Check this page regularly for updates.",
  },
  terms2: {
    title: "Terms and Conditions",
    lastUpdated: "Last updated: july 9, 2025",
    introTitle: "Introduction",
    introBody:
      "Please read these terms and conditions carefully before using Our Service.",
    definitionsTitle: "Interpretation and Definitions",
    interpretation:
      "The words of which the initial letter is capitalized have meanings defined under the following conditions.",
    definitions:
      "The following definitions shall have the same meaning regardless of whether they appear in singular or plural.",
    affiliate:
      "Affiliate means an entity that controls, is controlled by or is under common control with a party......",
    country: "Country refers to: Sweden",
    company:
      "Company refers to Lirtna, referred to as either 'the Company', 'We', 'Us' or 'Our'.",
    device:
      "Device means any device that can access the Service such as a computer, a cellphone or a tablet..",
    service: "Service refers to the Website of Lirtna",
    termsDef:
      "Terms and Conditions mean these Terms that form the entire agreement between You and the Company..",
    thirdParty:
      "Third-party Social Media Service means any services provided by a third party",
    website: "Website refers to Lirtna, accessible from https://lirtna.com/ ",
    you: "You means the individual or entity accessing or using the Service.",
    acknowledgmentTitle: "Acknowledgment",
    acknowledgmentBody:
      "These are the Terms governing the use of this Service and the agreement between You and the Company..",
    linksTitle: "Links to Other Websites",
    linksBody:
      "Our Service may contain links to third-party sites not controlled by us",
    terminationTitle: "Termination",
    terminationBody:
      "We may terminate or suspend Your access immediately if You breach these Terms..",
    liabilityTitle: "Limitation of Liability",
    liabilityBody:
      "To the maximum extent permitted by law, we are not liable for indirect or consequential damages..",
    disclaimerTitle: "Disclaimer 'AS IS'",
    disclaimerBody:
      "The Service is provided 'as is' without warranties of any kind..",
    lawTitle: "Governing Law",
    lawBody:
      "The laws of Sweden shall govern these Terms and Your use of the Service..",
    disputesTitle: "Disputes Resolution",
    disputesBody:
      "If You have a dispute, You agree to try to resolve it informally first",
    euTitle: "EU Users",
    euBody:
      "EU consumers benefit from any mandatory provisions of their country's law..",
    usTitle: "United States Legal Compliance",
    usBody:
      "You confirm you're not in a US-sanctioned country or on any restricted list..",
    severabilityTitle: "Severability and Waiver",
    severabilityBody:
      "If any provision is held to be invalid, the rest remain in effect..",
    translationTitle: "Translation",
    translationBody:
      "In case of dispute, the original English text shall prevail..",
    changesTitle: "Changes to Terms",
    changesBody:
      "We may change these Terms at any time. Continued use means acceptance..",
  },
  months: {
    "01": "January",
    "02": "February",
    "03": "March",
    "04": "April",
    "05": "May",
    "06": "June",
    "07": "July",
    "08": "August",
    "09": "September",
    10: "October",
    11: "November",
    12: "December",
  },
};
